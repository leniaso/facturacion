/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.facturacion;

/**
 *
 * @author diego.rendons
 */
public class Habitacion {
    // Constantes para las tarifas de las habitaciones
    public static final double TARIFA_SENCILLA = 118000;
    public static final double TARIFA_DOBLE = 254000;
    public static final double TARIFA_LUJO = 400000;
    
    String tipo;
    double tarifaPorNoche;

    // Constructor que establece el tipo de la habitación y asigna la tarifa correspondiente
    public Habitacion(String tipo) {
        this.tipo = tipo;
        this.tarifaPorNoche = obtenerTarifaPorTipo(tipo);
    }

    // Método estático para obtener la tarifa basada en el tipo de habitación
    public static double obtenerTarifaPorTipo(String tipo) {
    switch (tipo.toUpperCase()) { // Convierte el tipo a mayúsculas
        case "SENCILLA":
            return TARIFA_SENCILLA;
        case "DOBLE": // Asegúrate de que las opciones estén en mayúsculas
            return TARIFA_DOBLE;
        case "LUJO":
            return TARIFA_LUJO;
        default:
            System.out.println("Tipo de habitación no reconocido. Se ha establecido la tarifa a 0.");
            return 0;
    }
}


    // Método para calcular el costo total basado en el número de noches
    public double calcularCosto(int noches) {
        return tarifaPorNoche * noches;
    }
}
