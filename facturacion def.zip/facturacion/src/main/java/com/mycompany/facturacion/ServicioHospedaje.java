/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.facturacion;

/**
 *
 * @author diego.rendons
 */
import java.util.ArrayList;

class ServicioHospedaje {
    Cliente cliente;
    Habitacion habitacion;
    ArrayList<Incidente> incidentes = new ArrayList<>();
    int noches;
    double costoLavanderiaPorNoche = 60000; // Costo fijo por noche de lavandería
    double costoDanios = 0; // Inicializa los costos de daños
    double costoRobos = 0; // Inicializa los costos de robos

    // Constructor
    public ServicioHospedaje(Cliente cliente, Habitacion habitacion, int noches) {
        this.cliente = cliente;
        this.habitacion = habitacion;
        this.noches = noches;
    }

    // Agrega un incidente al ArrayList de incidentes
    public void agregarIncidente(Incidente incidente) {
        incidentes.add(incidente);
    }

    // Calcula el total sin incluir lavandería, daños ni robos
    public double calcularTotal() {
        double total = habitacion.calcularCosto(noches);
        for (Incidente incidente : incidentes) {
            total += incidente.costo;
        }
        return total;
    }

    // Establece el costo de daños
    public void setCostoDanios(double costoDanios) {
        this.costoDanios = costoDanios;
    }

    // Establece el costo de robos
    public void setCostoRobos(double costoRobos) {
        this.costoRobos = costoRobos;
    }

    // Calcula el total incluyendo lavandería, pero sin daños ni robos
    public double calcularTotalConLavanderia() {
        double total = calcularTotal();
        total += costoLavanderiaPorNoche * noches;
        return total;
    }

    // Calcula el total final incluyendo todos los adicionales: lavandería, daños y robos
    public double calcularTotalConAdicionales() {
        double total = calcularTotalConLavanderia();
        total += costoDanios + costoRobos; // Añade los costos de daños y robos
        return total;
    }
}
