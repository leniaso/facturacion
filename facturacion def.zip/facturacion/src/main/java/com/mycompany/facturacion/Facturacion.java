/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.facturacion;

/**
 *
 * @author diego.rendons
 */



import java.util.Scanner; // Importa la clase Scanner correctamente.

public class Facturacion {

    public static void main(String[] args) {
        Lectura lectura = new Lectura();

        // Solicitar datos del cliente al usuario
        String nombreCliente = lectura.leerString("Ingrese el nombre del cliente:");
        String identificacionCliente = lectura.leerString("Ingrese la identificación del cliente:");
        Cliente cliente = new Cliente(nombreCliente, identificacionCliente);

        // Solicitar el tipo de habitación al usuario
        String tipoHabitacion = lectura.leerString("Ingrese el tipo de habitación (Sencilla, Doble, Lujo):");
        Habitacion habitacion = new Habitacion(tipoHabitacion);

        // Solicitar la duración de la estancia
        int noches = lectura.leerInt("Ingrese el número de noches:");
        ServicioHospedaje servicioHospedaje = new ServicioHospedaje(cliente, habitacion, noches);

        // Preguntar sobre daños
        System.out.println("¿Hubo daños en la habitación? (sí/no):");
        String huboDanios = lectura.leerString("");
        if ("sí".equalsIgnoreCase(huboDanios)) {
            double costoDanios = lectura.leerDouble("Ingrese el costo de los daños:");
            servicioHospedaje.setCostoDanios(costoDanios);
        }

        // Preguntar sobre robos
        System.out.println("¿Hubo robos durante la estancia? (sí/no):");
        String huboRobos = lectura.leerString("");
        if ("sí".equalsIgnoreCase(huboRobos)) {
            double costoRobos = lectura.leerDouble("Ingrese el costo de los robos:");
            servicioHospedaje.setCostoRobos(costoRobos);
        }

        // Calcular y mostrar el total a facturar con todos los adicionales
        double totalFacturaConAdicionales = servicioHospedaje.calcularTotalConAdicionales();
        System.out.println("Total a facturar con todos los adicionales: $" + totalFacturaConAdicionales);
    }
}





